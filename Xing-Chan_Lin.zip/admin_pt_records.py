import sqlite3

from tkinter import *
import tkinter.messagebox
import tkinter.font as tkFont
from dr_see_pxhis import WindowForPxHis

class WindowForptrecord:

    def __init__(self, maptr):

        self.maptr = maptr

        # create frame
        self.leftmaptr = Frame(self.maptr, width=550, height=720, bg='pink')
        self.leftmaptr.pack(side=LEFT)
        self.rightmaptr = Frame(self.maptr, width=650, height=720, bg='light yellow')
        self.rightmaptr.pack(side=RIGHT)

        # create font
        self.f1 = tkFont.Font(family='times', size='16')

        # heading
        self.lhmaptr = Label(self.leftmaptr, text="Manage patients' records", font=self.f1, fg='black', bg='pink')
        self.lhmaptr.place(x=0, y=0)

        # Left Labels
        self.lptID = Label(self.leftmaptr, text="Enter patient's NHS number:", font=self.f1, fg='black', bg='pink')
        self.lptID.place(x=0, y=80)
        self.lpxNo = Label(self.leftmaptr, text="Enter patient's prescription no.(The first column)", font=self.f1, fg='black', bg='pink')
        self.lpxNo.place(x=0, y=250)

        # entry for left labels
        self.ptIDleft_ent = Entry(self.leftmaptr, width=15)
        self.ptIDleft_ent.place(x=200, y=80)
        self.pxNo_ent = Entry(self.leftmaptr, width=3)
        self.pxNo_ent.place(x=330, y=250)

        # button for submitting
        self.bu_ptID = Button(self.leftmaptr, text="Submit patient's ID", width=15, height=2, bg='white', command=self.ptIDsubmit)
        self.bu_ptID.place(x=400, y=78)
        self.bu_pxNo = Button(self.leftmaptr, text="Submit presciption No.", width=17, height=2, bg='white', command=self.pxNosubmit)
        self.bu_pxNo.place(x=390, y=248)

    def ptIDsubmit(self):

        try:
            # getting user inputs
            self.patientID = int(self.ptIDleft_ent.get())

        except ValueError:
            tkinter.messagebox.showinfo('Warning', 'Please enter an integer.')

        else:
            # check exist ptIDs
            conn_check_ID = sqlite3.connect('Database.db')
            c_check_ID = conn_check_ID.cursor()

            re_pt_id = c_check_ID.execute("SELECT ptID FROM ptbasic")

            li_exi_ptID = []
            for r in re_pt_id:
                li_exi_ptID.append(r[0])

            if self.patientID not in li_exi_ptID:
                tkinter.messagebox.showinfo('Warning',
                                            "The database doesn't have this patient. Please re-enter a valid number")
            else:
                # see the records
                root_ptrecord = Tk()
                WindowForPxHis(root_ptrecord, self.patientID)

                # resolution of the window
                root_ptrecord.geometry('500x200+0+0')

                # preventing the resize feature
                root_ptrecord.resizable(True, True)

                # end the loop
                root_ptrecord.mainloop()


    def pxNosubmit(self):

        try:
            self.ptpxNo = int(self.pxNo_ent.get())

        except ValueError:
            tkinter.messagebox.showinfo('Warning', 'Please enter an integer.')

        else:
            # check valid
            li_pxNo = []

            conn_valid_pxno = sqlite3.connect('Database.db')
            c_pxno = conn_valid_pxno.cursor()
            re_pxno = c_pxno.execute("SELECT orderNo FROM prescription WHERE orderNo = (?)",(self.ptpxNo,))

            for re in re_pxno:
                li_pxNo.append(re[0])

            if self.ptpxNo not in li_pxNo:
                tkinter.messagebox.showinfo('Warning', 'Invalid prescription No.')
            else:
                self.ptrecord_view()


    def ptrecord_view(self):

        # connect to the database
        conn_pt_view = sqlite3.connect('Database.db')
        # create a cursor
        c_mapt = conn_pt_view.cursor()

        re_ptrecord = c_mapt.execute(
            "SELECT ptID,DrID,Drname,appointmentTime,medname1,day1,dosage1,adm1 from prescription WHERE orderNo = (?)", (self.ptpxNo,))

        for data in re_ptrecord:

            ptID_view = data[0]
            DrID_view = data[1]
            Drname_view = data[2]
            date_view = data[3]
            medname_view = data[4]
            day1_view = data[5]
            dosage1_view = data[6]
            adm1_view = data[7]

            # labels
            # NHS number
            lptIDview = Label(self.rightmaptr, text="Patient's NHS number :  " + str(ptID_view), font=self.f1, fg='black',
                              bg='light yellow')
            lptIDview.place(x=0, y=40)
            lDrID_view = Label(self.rightmaptr, text="GP's ID:  " + str(DrID_view), font=self.f1, fg='black', bg='light yellow')
            lDrID_view.place(x=0, y=110)
            lDrname_view = Label(self.rightmaptr, text="GP's Name:  "+ str(Drname_view), font=self.f1, fg='black', bg='light yellow')
            lDrname_view.place(x=0, y=180)
            ldate_view = Label(self.rightmaptr, text='Appointment Time:  ' + str(date_view), font=self.f1, fg='black', bg='light yellow')
            ldate_view.place(x=0, y=250)
            lmedname_view = Label(self.rightmaptr, text='Medicine Name', font=self.f1, fg='black', bg='light yellow')
            lmedname_view.place(x=0, y=320)
            lday1_view = Label(self.rightmaptr, text='Day:', font=self.f1, fg='black', bg='light yellow')
            lday1_view.place(x=0, y=390)
            ldosage1_view = Label(self.rightmaptr, text='Dosage', font=self.f1, fg='black', bg='light yellow')
            ldosage1_view.place(x=0, y=460)
            ladm1_view = Label(self.rightmaptr, text='Administration(How to use)', font=self.f1, fg='black', bg='light yellow')
            ladm1_view.place(x=0, y=530)

            # entry for right labels
            self.mednameview_ent = Entry(self.rightmaptr, width=15)
            self.mednameview_ent.insert(END, str(medname_view))
            self.mednameview_ent.place(x=200, y=320)

            self.day_ent = Entry(self.rightmaptr, width=15)
            self.day_ent.insert(END, str(day1_view))
            self.day_ent.place(x=200, y=390)

            self.dosage_ent = Entry(self.rightmaptr, width=15)
            self.dosage_ent.insert(END, str(dosage1_view))
            self.dosage_ent.place(x=200, y=460)

            self.adminview_ent = Entry(self.rightmaptr, width=15)
            self.adminview_ent.insert(END, str(adm1_view))
            self.adminview_ent.place(x=200, y=530)

            conn_pt_view.commit()

            # button for submitting
            self.bu_update = Button(self.rightmaptr, text="Update info.", width=12, height=2,
                                    bg='white', command=self.update_info)
            self.bu_update.place(x=140, y=600)
            self.bu_delpt = Button(self.rightmaptr, text="Delete record.", width=12, height=2,
                                    bg='white', command=self.delete_record)
            self.bu_delpt.place(x=260, y=600)


    def update_info(self):

        # getting the user inputs
        self.val71 = self.mednameview_ent.get()
        self.val72 = self.day_ent.get()
        self.val73 = self.dosage_ent.get()
        self.val74 = self.adminview_ent.get()

        if self.val71 == '' or self.val72 == '' or self.val73 =='' or self.val74 == '':
            tkinter.messagebox.showinfo('Warning','Please fill up all the boxes')

        elif not self.val72.isdigit() :
            tkinter.messagebox.showinfo('Warning','Day must be only integers.')

        else:
            # update the record
            # connect to the database on register page
            conn_upd = sqlite3.connect('Database.db')
            # create a cursor
            c_upd = conn_upd.cursor()
            c_upd.execute("UPDATE prescription SET medname1=(?), day1=(?), dosage1=(?), adm1=(?) WHERE orderNo = (?)"
                          ,(self.val71,self.val72,self.val73,self.val74,self.ptpxNo,))

            conn_upd.commit()
            conn_upd.close()
            tkinter.messagebox.showinfo('Confirmation', 'modification is successful.')


    def delete_record(self):

        tkinter.messagebox.showinfo('Warning', 'This will delete the record.')

        # Delete the record
        conn_delpt = sqlite3.connect('Database.db')
        c_delpt = conn_delpt.cursor()

        c_delpt.execute("DELETE FROM prescription WHERE orderNo = (?)", (self.ptpxNo,))

        conn_delpt.commit()
        conn_delpt.close()

        tkinter.messagebox.showinfo('Confirmation', 'Successful!')